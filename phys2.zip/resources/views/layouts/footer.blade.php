<footer class="footer">
          <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                    {{ date("Y",strtotime("-1 year")) }} - {{date('Y')}} ©  <span class="text-muted hide-phone pull-right">  Powered    <i class="mdi mdi-heart text-danger"></i> by TE-S</span>
                    </div>
                </div>
         </div>
</footer>